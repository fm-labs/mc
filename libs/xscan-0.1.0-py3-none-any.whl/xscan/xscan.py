import abc
import json
import os
import time

#from uuid_extensions import uuid7

from xscan.settings import DATA_DIR


def generate_scan_id(category, target):
    clean_target = target.lower()
    clean_target = (clean_target
                    .replace("http://", "")
                    .replace("https://", "")
                    .replace("/", "-")
                    .replace(":", "-"))
    return f"{category}-{clean_target}"

class ScanAbortException(Exception):
    """
    Exception raised when a scan is aborted
    """
    def __init__(self, message):
        super().__init__(message)
        self.message = message


class ScanRequest:
    """
    Class representing a scan request
    """

    def __init__(self, category, target, **kwargs):
        self.category = category
        self.target = target
        self.id = generate_scan_id(category, target)
        self.timestamp = int(time.time())
        self.kwargs = kwargs

        self.artifacts = list()
        self.findings = list()

        self.tmp_scan_dir = os.path.join(DATA_DIR, "tmp", "scans", str(self.id), str(self.timestamp))
        os.makedirs(self.tmp_scan_dir, exist_ok=True)
        self.artifacts_dir = os.path.join(DATA_DIR, "scans", str(self.id), str(self.timestamp))
        os.makedirs(self.artifacts_dir, exist_ok=True)

    def __repr__(self):
        return f"ScanRequest(mode={self.category}, target={self.target})"

    def get_tmp_scan_dir(self):
        """
        Get the temp scan directory
        """
        return self.tmp_scan_dir

    def get_artifact(self, artifact_name):
        """
        Get an artifact from the scan directory
        """
        artifact_file_path = os.path.join(self.artifacts_dir, artifact_name)
        if os.path.exists(artifact_file_path):
            with open(artifact_file_path, "r") as f:
                return f.read()
        return None

    def get_artifact_file(self, artifact_name):
        """
        Get an artifact file from the scan directory
        """
        artifact_file_path = os.path.join(self.artifacts_dir, artifact_name)
        if os.path.exists(artifact_file_path):
            return artifact_file_path
        return None

    def add_artifact_file(self, artifact_name, file_path):
        """
        Add an artifact to the scan directory
        """
        artifact_file_path = os.path.join(self.artifacts_dir, artifact_name)
        os.makedirs(os.path.dirname(artifact_file_path), exist_ok=True)
        os.rename(file_path, artifact_file_path)

        self.artifacts.append(artifact_name)
        return artifact_file_path

    def add_artifact(self, artifact_name, artifact: str):
        """
        Add an artifact to the scan directory
        """
        artifact_file_path = os.path.join(self.artifacts_dir, artifact_name)
        os.makedirs(os.path.dirname(artifact_file_path), exist_ok=True)
        with open(artifact_file_path, "w") as f:
            f.write(artifact)

        self.artifacts.append(artifact_name)
        return artifact_file_path

    def add_finding(self, **kwargs):
        """
        Add a finding to the scan
        """
        # kwargs to dict
        finding = dict()
        for key, value in kwargs.items():
            finding[key] = value

        self.findings.append(finding)
        return finding

    def dump_findings(self):
        findings_json_str = json.dumps(self.findings, indent=4)
        self.add_artifact("xscan/findings.json", findings_json_str)

    def dump_last_scan_timestamp(self):
        last_scan_file = os.path.join(DATA_DIR, "scans", self.id, "last_scan")
        os.makedirs(os.path.dirname(last_scan_file), exist_ok=True)
        with open(last_scan_file, "w") as f:
            f.write(str(self.timestamp))

    def success(self):
        return ScanResult(self, 0, self.findings)

    def error(self, code, message):
        return ScanResult(self, code, message)

    def abort(self, message):
        raise ScanAbortException(message)

class ScanResult:
    """
    Class representing a scan result
    """

    def __init__(self, scan: ScanRequest, code, result):
        self.mode = scan.category
        self.target = scan.target
        self.code = code
        self.result = result

    def __repr__(self):
        return f"ScanResult(mode={self.mode}, target={self.target}, code={self.code}, result={self.result})"


class BaseScanner(abc.ABC):
    """
    Class representing a scanner instance
    """
    name = "BaseScanner"
    category = None
    description = "Base scanner class"

    def __repr__(self):
        return f"ScannerInstance(name={self.name}, mode={self.category}, description={self.description})"


    def run(self, scan: ScanRequest):
        """
        Perform the scan
        """
        print(f"Scanning {scan.target} with {self.name}...")
        # Simulate scan result
        result = f"Scan result for {scan.target} using {self.name}"
        return result


def init_scan(mode: str, target: str):
    """
    Initialize the scanner
    """
    scan = ScanRequest(mode, target)
    print(f"Scan initialized: {scan}")
    return scan


def report_scan_result(scan: ScanRequest, result: ScanResult):
    """
    Report the scan result.
    Print the scan result to the scan directory.
    """
    print(f"Scan result reported: {result}")
    scan_dir = scan.get_tmp_scan_dir()

    # Create a result file
    result_file = os.path.join(scan_dir, "scan_result.txt")
    with open(result_file, "w") as f:
        f.write(f"Scan result for {scan.target}:\n")
        f.write(f"Code: {result.code}\n")
        f.write(f"Result: {result.result}\n")
    print(f"Scan result saved to {result_file}")
