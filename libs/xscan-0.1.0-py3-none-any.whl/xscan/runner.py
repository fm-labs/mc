import os
import shutil

from xscan.xscan import ScanRequest, ScanAbortException


class ScanRunner:
    """
    ScanRunner is a class that manages the execution of scans using the XScan library.
    It handles the initialization of the scanner, loading of scanners, and execution of scans.
    """

    def __init__(self, scanners: list=None):
        """
        Initializes the ScanRunner instance.
        """
        self.scanners = scanners
        if not self.scanners:
            self.scanners = list()


    def load_scanners(self, scanners: list):
        """
        Loads the scanners for the scanner.
        """
        for scanner in scanners:
            if scanner not in self.scanners:
                self.scanners.append(scanner)

    def execute_scan(self, scan: ScanRequest):
        """
        Executes the scan using the loaded scanners.
        """
        print(f"Starting new scan {scan.id} for {scan.category}={scan.target}...")
        for scanner in self.scanners:
            try:
                if scanner.category != scan.category:
                    #print(f"Skipping {scanner.__name__} for category {scan.category}")
                    continue

                print(f"Running {scanner.__name__} for target={scan.target}...")
                scanner_instance = scanner()
                scanner_instance.run(scan)
            except ScanAbortException as e:
                print(f"Scan aborted: {e}")
                break
            except Exception as e:
                print(f"Error running {scanner.__name__}: {e}")
                continue
                #scan.error(1, str(e))
                #return scan

        scan.dump_findings()
        scan.dump_last_scan_timestamp()

        # cleanup
        tmp_scan_dir = scan.get_tmp_scan_dir()
        print(f"Cleaning up tmp scan directory: {tmp_scan_dir}")
        if os.path.exists(tmp_scan_dir):
            shutil.rmtree(tmp_scan_dir, ignore_errors=True)

        artifacts = scan.artifacts
        for artifact_name in artifacts:
            #artifact = scan.get_artifact(artifact_name)
            print(f"> Artifact: {artifact_name}")

        findings = scan.findings
        for finding in findings:
            print(f"! Finding: {finding}")

        print(f"Scan {scan.id} finished.")
        return scan