from xscan.helper.trivy_helper import run_trivy_repo_scan
from xscan.xscan import BaseScanner


class TrivyRepoScanner(BaseScanner):
    """
    Scan source code repositories for vulnerabilities using Trivy
    """
    name = "trivy_repo"
    category = "repo"
    description = "Scan source code repositories for vulnerabilities using Trivy"

    def run(self, scan):
        tmp_dir = scan.get_tmp_scan_dir()

        env = scan.kwargs["environment"] if "environment" in scan.kwargs else {}

        # Run Trivy scan
        trivy_result = run_trivy_repo_scan(scan.target, "vuln", output_format="json", env=env)
        scan.add_artifact("trivy/repo_vuln.json", trivy_result)

        trivy_result = run_trivy_repo_scan(scan.target, "misconfig", output_format="json", env=env)
        scan.add_artifact("trivy/repo_misconfig.json", trivy_result)

        trivy_result = run_trivy_repo_scan(scan.target, "license", output_format="json", env=env)
        scan.add_artifact("trivy/repo_license.json", trivy_result)

        trivy_result = run_trivy_repo_scan(scan.target, "secret", output_format="json", env=env)
        scan.add_artifact("trivy/repo_secrets.json", trivy_result)
