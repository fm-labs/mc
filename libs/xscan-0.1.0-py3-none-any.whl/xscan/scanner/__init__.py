
# Scan docker/OCI images for vulnerabilities

# - docker scout cves
# - docker scout sbom
# - docker scout recommendations
# - trivy
# - anchore
# - clair
# - grype
# - syft
# - oscap
# - docker scan
# - docker-bench-security
# - kube-bench
# - kube-hunter
# - kube-score
# - kubeaudit