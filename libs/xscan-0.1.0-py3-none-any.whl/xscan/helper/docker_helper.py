import subprocess

from xscan import settings


def run_docker_image_pull(image_name):
    """
    Pull docker images from registry
    """
    try:
        print(f"Pulling {image_name} ...")
        # Run Docker pull command
        cmd = [settings.DOCKER_BIN, "pull", image_name]
        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Print the output
        print(result.stdout.decode())
        return result.stdout.decode()
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr.decode()}")
        raise e