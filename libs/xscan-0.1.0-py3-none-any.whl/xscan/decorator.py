from xscan.xscan import init_scan, report_scan_result, ScanResult


def scanner(name: str, mode: str, description: str):
    """
    Decorator to register a scanner
    """
    print(f"Init Scanner: {name}")

    def decorator(func):

        def wrapper(*args, **kwargs):
            # Initialize the scan
            scan = init_scan(mode, args[0])
            # Add the scan object to kwargs
            kwargs["scan"] = scan
            # Call the original function
            try:
                result = func(*args, **kwargs)
                if not isinstance(result, ScanResult):
                    result = ScanResult(scan, 0, result)

            except Exception as e:
                # Handle exceptions and set result to error
                print(f"Error during scan: {e}")
                result = ScanResult(scan, 1, str(e))

            # Report the scan result
            report_scan_result(scan, result)
            return result

        # Register the scanner
        #wrapper.name = name
        #wrapper.mode = mode
        #wrapper.description = description
        return wrapper

    return decorator