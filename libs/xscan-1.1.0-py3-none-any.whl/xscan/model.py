import os
import tempfile
import time


def build_scan_target_id(target):
    clean_target = target.lower()
    clean_target = (clean_target
                    .replace("http://", "")
                    .replace("https://", "")
                    .replace("/", "-")
                    .replace(":", "-"))
    return f"{clean_target}"



class ScanConfig:
    """
    Class representing a scan request
    """

    def __init__(self, mode, target, output_dir=None, tmp_dir=None, ref=None, **kwargs):
        self.mode = mode
        self.target = target
        self.ref = ref # reference ID for the scan, e.g., UUID

        self.target_id = build_scan_target_id(target)
        self.timestamp = int(time.time())
        self.kwargs = kwargs

        self._tmp_dir = tempfile.TemporaryDirectory(prefix=f"xscan-{self.target_id}-")
        self.tmp_dir = tmp_dir if tmp_dir else self._tmp_dir.name

        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            self.artifacts_dir = output_dir
        else:
            self._tmp_artifacts_dir = tempfile.TemporaryDirectory(prefix=f"xscan-artifacts-{self.target_id}-")
            self.artifacts_dir = self._tmp_artifacts_dir.name

    def __str__(self):
        return f"ScanConfig(mode={self.mode}, target={self.target}, id={self.target_id}, timestamp={self.timestamp}, artifacts_dir={self.artifacts_dir})"

    def __repr__(self):
        return str(self)



class ScanResult:
    """
    Class representing a scan result
    """

    def __init__(self, scan: ScanConfig, code=0, result=None):
        self.mode = scan.mode
        self.target = scan.target
        self.code = code
        self.result = result
        self.findings = list()

        self.artifacts = list()
        self.artifacts_dir = scan.artifacts_dir

    def __repr__(self):
        return f"ScanResult(mode={self.mode}, target={self.target}, code={self.code}, result={self.result})"

    def get_artifact(self, artifact_name):
        """
        Get an artifact from the scan directory
        """
        artifact_file_path = os.path.join(self.artifacts_dir, artifact_name)
        if os.path.exists(artifact_file_path):
            with open(artifact_file_path, "r") as f:
                return f.read()
        return None

    def get_artifact_file(self, artifact_name):
        """
        Get an artifact file from the scan directory
        """
        artifact_file_path = os.path.join(self.artifacts_dir, artifact_name)
        if os.path.exists(artifact_file_path):
            return artifact_file_path
        return None

    def add_artifact_file(self, artifact_name, file_path):
        """
        Add an artifact to the scan directory
        """
        artifact_file_path = os.path.join(self.artifacts_dir, artifact_name)
        os.makedirs(os.path.dirname(artifact_file_path), exist_ok=True)
        os.rename(file_path, artifact_file_path)

        print(f"[+] Artifact saved: {artifact_file_path}")
        self.artifacts.append(artifact_name)
        return artifact_file_path

    def add_artifact(self, artifact_name, artifact: str):
        """
        Add an artifact to the scan directory
        """
        artifact_file_path = os.path.join(self.artifacts_dir, artifact_name)
        os.makedirs(os.path.dirname(artifact_file_path), exist_ok=True)
        with open(artifact_file_path, "w") as f:
            f.write(artifact)

        print(f"[+] Artifact saved: {artifact_file_path}")
        self.artifacts.append(artifact_name)
        return artifact_file_path

    # def add_finding(self, **kwargs):
    #     """
    #     Add a finding to the scan
    #     """
    #     # kwargs to dict
    #     finding = dict()
    #     for key, value in kwargs.items():
    #         finding[key] = value
    #
    #     self.findings.append(finding)
    #     return finding

    # def dump_findings(self):
    #     findings_json_str = json.dumps(self.findings, indent=4)
    #     self.add_artifact("xscan/findings.json", findings_json_str)