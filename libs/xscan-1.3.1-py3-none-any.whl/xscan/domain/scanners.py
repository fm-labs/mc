import asyncio
import importlib
import inspect
import pkgutil
import sys
import os
import json

from xscan.base import BaseScanner
from xscan.model import ScanConfig


class WebcheckDomainScanner(BaseScanner):
    name = "webcheck_domain_scanner"
    mode = "domain"
    description = "Scan domains for vulnerabilities using webcheck tool methods (ported to python)"

    PER_HANDLER_TIMEOUT = 15  # seconds
    MAX_PARALLEL_HANDLERS = 5

    def __init__(self):
        super().__init__()
        self.handlers = []

        # enumerate all python files in the xscan.domain.webcheck module directory
        # and import the "handler" function from each file

        module_path = "xscan.domain.webcheck"
        package = importlib.import_module(module_path)
        package_path = os.path.dirname(package.__file__)

        excluded_modules = ["__init__", "trace-route"]

        for _, module_name, is_pkg in pkgutil.iter_modules([package_path]):
            if not is_pkg and module_name not in excluded_modules:
                full_module_name = f"{module_path}.{module_name}"
                try:
                    module = importlib.import_module(full_module_name)
                    if hasattr(module, "handler"):
                        handler_func = getattr(module, "handler")
                        self.handlers.append(handler_func)
                        print(f"Loaded webcheck handler: {full_module_name}.handler")
                    else:
                        print(f"No handler function found in module: {full_module_name}")
                except Exception as e:
                    print(f"Error importing module {full_module_name}: {e}")
                    continue


    async def run(self, scan, result):
        if not self.handlers:
            result.add_artifact("webcheck/results.json", json.dumps([]))
            return result

        # limit parallelism
        sem = asyncio.Semaphore(self.MAX_PARALLEL_HANDLERS)

        async def call(h):
            name = f"{h.__module__}.{getattr(h, '__qualname__', getattr(h, '__name__', 'handler'))}"
            try:
                async with sem:
                    print(f"→ starting: {name}")
                    if inspect.iscoroutinefunction(h):
                        out = await asyncio.wait_for(
                            h(scan.target), timeout=self.PER_HANDLER_TIMEOUT
                        )
                    else:
                        # run blocking handler in a thread so it can't block the loop
                        out = await asyncio.wait_for(
                            asyncio.to_thread(h, scan.target),
                            timeout=self.PER_HANDLER_TIMEOUT,
                        )
                    print(f"✓ done: {name}")
                    return {"handler": name, "result": out}
            except asyncio.TimeoutError:
                # IMPORTANT: the underlying thread may keep running, but we return so gather won't hang
                msg = f"timeout after {self.PER_HANDLER_TIMEOUT}s"
                print(f"✗ timeout: {name} ({msg})")
                return {"handler": name, "error": msg}
            except Exception as e:
                print(f"✗ error: {name} ({type(e).__name__}: {e})")
                return {"handler": name, "error": f"{type(e).__name__}: {e}"}

        tasks = [asyncio.create_task(call(h)) for h in self.handlers]
        print(f"Running {len(tasks)} webcheck handlers for target: {scan.target}...")
        results = await asyncio.gather(*tasks, return_exceptions=True)
        print(f"Executed {len(tasks)} webcheck handlers for target: {scan.target}.")

        result.add_artifact("webcheck/results.json", json.dumps(results))
        return result


DEFAULT_DOMAIN_SCANNERS = [
    WebcheckDomainScanner,
]