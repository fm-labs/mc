import requests
from bs4 import BeautifulSoup
import re
import json

class Wappalyzer:
    def __init__(self, options=None):
        self.options = options or {}
        self.technologies = {}
        
    async def init(self):
        # Load technology definitions
        self.technologies = {
            'jQuery': {
                'js': ['jQuery', '$'],
                'html': ['<script[^>]+jquery'],
            },
            'React': {
                'js': ['React', 'ReactDOM'],
                'html': ['<div[^>]+data-reactroot'],
            },
            'Angular': {
                'js': ['angular', 'ng'],
                'html': ['ng-app', 'ng-controller'],
            },
            'Vue.js': {
                'js': ['Vue'],
                'html': ['v-if', 'v-for', 'v-model'],
            },
            'Bootstrap': {
                'css': ['bootstrap'],
                'html': ['class="[^"]*bootstrap'],
            },
            'WordPress': {
                'html': ['wp-content', 'wp-includes'],
                'headers': {'x-pingback': 'xmlrpc.php'},
            },
            'Apache': {
                'headers': {'server': 'Apache'},
            },
            'Nginx': {
                'headers': {'server': 'nginx'},
            },
            'PHP': {
                'headers': {'x-powered-by': 'PHP'},
                'html': ['\.php'],
            },
            'Node.js': {
                'headers': {'x-powered-by': 'Express'},
            }
        }
        
    async def open(self, url, headers=None, storage=None):
        return Site(url, headers or {}, storage or {}, self.technologies)
        
    async def destroy(self):
        pass

class Site:
    def __init__(self, url, headers, storage, technologies):
        self.url = url
        self.headers = headers
        self.storage = storage
        self.technologies = technologies
        
    async def analyze(self):
        try:
            response = requests.get(self.url, timeout=10)
            response.raise_for_status()
            
            html_content = response.text
            response_headers = dict(response.headers)
            
            detected_technologies = []
            
            for tech_name, tech_config in self.technologies.items():
                if self._detect_technology(tech_name, tech_config, html_content, response_headers):
                    detected_technologies.append({
                        'name': tech_name,
                        'confidence': 100,
                        'version': None,
                        'icon': f"{tech_name.lower()}.png",
                        'website': f"https://{tech_name.lower()}.com",
                        'cpe': None
                    })
            
            return {
                'url': self.url,
                'technologies': detected_technologies
            }
            
        except Exception as e:
            raise Exception(f"Error analyzing site: {str(e)}")
    
    def _detect_technology(self, name, config, html, headers):
        # Check HTML patterns
        if 'html' in config:
            for pattern in config['html']:
                if re.search(pattern, html, re.IGNORECASE):
                    return True
        
        # Check JavaScript patterns
        if 'js' in config:
            for pattern in config['js']:
                if pattern.lower() in html.lower():
                    return True
        
        # Check CSS patterns
        if 'css' in config:
            for pattern in config['css']:
                if pattern.lower() in html.lower():
                    return True
        
        # Check headers
        if 'headers' in config:
            for header_name, header_pattern in config['headers'].items():
                if header_name.lower() in [h.lower() for h in headers.keys()]:
                    header_value = headers.get(header_name, '')
                    if header_pattern.lower() in header_value.lower():
                        return True
        
        return False

async def techStackHandler(url):
    options = {}
    wappalyzer = Wappalyzer(options)
    
    try:
        await wappalyzer.init()
        headers = {}
        storage = {
            'local': {},
            'session': {}
        }
        site = await wappalyzer.open(url, headers, storage)
        results = await site.analyze()
        
        if not results.get('technologies') or len(results['technologies']) == 0:
            raise Exception('Unable to find any technologies for site')
        
        return results
        
    except Exception as error:
        raise Exception(str(error))
        
    finally:
        await wappalyzer.destroy()

handler = techStackHandler