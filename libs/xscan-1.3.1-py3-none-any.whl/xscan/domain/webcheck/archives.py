import requests
from datetime import datetime

def convert_timestamp_to_date(timestamp):
    year = int(timestamp[0:4])
    month = int(timestamp[4:6]) - 1
    day = int(timestamp[6:8])
    hour = int(timestamp[8:10])
    minute = int(timestamp[10:12])
    second = int(timestamp[12:14])
    
    return datetime(year, month + 1, day, hour, minute, second)

def count_page_changes(results):
    prev_digest = None
    count = -1
    for curr in results:
        if curr[2] != prev_digest:
            prev_digest = curr[2]
            count += 1
    return count

def get_average_page_size(scans):
    total_size = sum(int(scan[3]) for scan in scans)
    return round(total_size / len(scans))

def get_scan_frequency(first_scan, last_scan, total_scans, change_count):
    def format_to_two_decimal(num):
        return round(float(num), 2)
    
    day_factor = (last_scan - first_scan).total_seconds() / (1000 * 60 * 60 * 24)
    days_between_scans = format_to_two_decimal(day_factor / total_scans)
    days_between_changes = format_to_two_decimal(day_factor / change_count)
    scans_per_day = format_to_two_decimal((total_scans - 1) / day_factor)
    changes_per_day = format_to_two_decimal(change_count / day_factor)
    
    return {
        'daysBetweenScans': days_between_scans,
        'daysBetweenChanges': days_between_changes,
        'scansPerDay': scans_per_day,
        'changesPerDay': changes_per_day,
    }

def wayback_handler(url):
    cdx_url = f"https://web.archive.org/cdx/search/cdx?url={url}&output=json&fl=timestamp,statuscode,digest,length,offset"
    
    try:
        response = requests.get(cdx_url)
        data = response.json()
        
        if not data or not isinstance(data, list) or len(data) <= 1:
            return {'skipped': 'Site has never before been archived via the Wayback Machine'}
        
        data.pop(0)
        
        first_scan = convert_timestamp_to_date(data[0][0])
        last_scan = convert_timestamp_to_date(data[-1][0])
        total_scans = len(data)
        change_count = count_page_changes(data)
        
        return {
            'firstScan': first_scan,
            'lastScan': last_scan,
            'totalScans': total_scans,
            'changeCount': change_count,
            'averagePageSize': get_average_page_size(data),
            'scanFrequency': get_scan_frequency(first_scan, last_scan, total_scans, change_count),
            'scans': data,
            'scanUrl': url,
        }
    except Exception as err:
        return {'error': f'Error fetching Wayback data: {str(err)}'}

handler = wayback_handler