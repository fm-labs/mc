import os
import urllib.request
import urllib.parse
import urllib.error

async def features_handler(url):
    api_key = os.environ.get('BUILT_WITH_API_KEY')
    
    if not url:
        raise ValueError('URL query parameter is required')
    
    if not api_key:
        raise ValueError('Missing BuiltWith API key in environment variables')
    
    api_url = f"https://api.builtwith.com/free1/api.json?KEY={api_key}&LOOKUP={urllib.parse.quote(url)}"
    
    try:
        with urllib.request.urlopen(api_url) as response:
            if 200 <= response.status <= 299:
                return response.read().decode('utf-8')
            else:
                raise Exception(f"Request failed with status code: {response.status}")
    except urllib.error.URLError as error:
        raise Exception(f"Error making request: {str(error)}")
    except Exception as error:
        raise Exception(f"Error making request: {str(error)}")

handler = features_handler