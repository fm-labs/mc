import socket
from urllib.parse import urlparse

async def txt_record_handler(url, event=None, context=None):
    try:
        parsed_url = urlparse(url)
        
        txt_records = socket.getaddrinfo(parsed_url.hostname, None)
        
        # Get TXT records using socket - this is a simplified implementation
        # In practice, you might want to use dnspython library for proper DNS resolution
        try:
            import dns.resolver
            resolver = dns.resolver.Resolver()
            answers = resolver.resolve(parsed_url.hostname, 'TXT')
            txt_records = [str(rdata).strip('"') for rdata in answers]
        except ImportError:
            # Fallback if dnspython is not available
            txt_records = []
        
        # Parsing and formatting TXT records into a single object
        readable_txt_records = {}
        for record_array in txt_records:
            record_strings = [record_array] if isinstance(record_array, str) else record_array
            for record_string in record_strings:
                split_record = record_string.split('=')
                key = split_record[0]
                value = '='.join(split_record[1:]) if len(split_record) > 1 else ''
                readable_txt_records[key] = value
        
        return readable_txt_records
        
    except Exception as error:
        if 'Invalid URL' in str(error):
            raise Exception(f"Invalid URL {error}")
        else:
            raise error

handler = txt_record_handler