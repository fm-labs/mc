import ssl
import socket
from urllib.parse import urlparse

def ssl_handler(url_string):
    try:
        parsed_url = urlparse(url_string)
        hostname = parsed_url.hostname
        port = parsed_url.port or 443
        
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        
        with socket.create_connection((hostname, port)) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert(binary_form=False)
                
                if not cert:
                    raise Exception(f"""
          No certificate presented by the server.

          The server is possibly not using SNI (Server Name Indication) to identify itself, and you are connecting to a hostname-aliased IP address.
          Or it may be due to an invalid SSL certificate, or an incomplete SSL handshake at the time the cert is being read.""")
                
                return cert
                
    except Exception as error:
        raise Exception(str(error))

handler = ssl_handler