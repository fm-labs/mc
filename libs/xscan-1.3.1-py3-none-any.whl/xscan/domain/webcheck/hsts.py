import urllib.request
import urllib.error
import json
import re

def hsts_handler(url, event=None, context=None):
    def error_response(message, status_code=500):
        return {
            "statusCode": status_code,
            "body": json.dumps({"error": message}),
        }
    
    def hsts_incompatible(message, compatible=False, hsts_header=None):
        return {"message": message, "compatible": compatible, "hstsHeader": hsts_header}
    
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as response:
            headers = response.headers
            hsts_header = headers.get('strict-transport-security')
            
            if not hsts_header:
                return hsts_incompatible("Site does not serve any HSTS headers.")
            else:
                max_age_match = re.search(r'max-age=(\d+)', hsts_header)
                includes_sub_domains = 'includeSubDomains' in hsts_header
                preload = 'preload' in hsts_header
                
                if not max_age_match or int(max_age_match.group(1)) < 10886400:
                    return hsts_incompatible("HSTS max-age is less than 10886400.")
                elif not includes_sub_domains:
                    return hsts_incompatible("HSTS header does not include all subdomains.")
                elif not preload:
                    return hsts_incompatible("HSTS header does not contain the preload directive.")
                else:
                    return hsts_incompatible("Site is compatible with the HSTS preload list!", True, hsts_header)
                    
    except urllib.error.URLError as error:
        return error_response(f"Error making request: {str(error)}")
    except Exception as error:
        return error_response(f"Error making request: {str(error)}")

handler = hsts_handler