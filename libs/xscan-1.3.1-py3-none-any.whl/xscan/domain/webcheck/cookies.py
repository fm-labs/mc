import asyncio
import aiohttp
from pyppeteer import launch

async def get_puppeteer_cookies(url):
    browser = await launch({
        'headless': True,
        'args': ['--no-sandbox', '--disable-setuid-sandbox']
    })
    
    try:
        page = await browser.newPage()
        navigation_task = page.goto(url, {'waitUntil': 'networkidle2'})
        timeout_task = asyncio.sleep(3)
        
        done, pending = await asyncio.wait([navigation_task, timeout_task], return_when=asyncio.FIRST_COMPLETED)
        
        for task in pending:
            task.cancel()
            
        if timeout_task in done:
            raise Exception('Puppeteer took too long!')
            
        return await page.cookies()
    finally:
        await browser.close()

async def cookie_handler(url):
    header_cookies = None
    client_cookies = None
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, max_redirects=5) as response:
                header_cookies = response.headers.get('set-cookie')
    except aiohttp.ClientError as error:
        return {'error': f'Request failed: {str(error)}'}
    except Exception as error:
        return {'error': f'Error setting up request: {str(error)}'}
    
    try:
        client_cookies = await get_puppeteer_cookies(url)
    except:
        client_cookies = None
    
    if not header_cookies and (not client_cookies or len(client_cookies) == 0):
        return {'skipped': 'No cookies'}
    
    return {'headerCookies': header_cookies, 'clientCookies': client_cookies}

handler = cookie_handler