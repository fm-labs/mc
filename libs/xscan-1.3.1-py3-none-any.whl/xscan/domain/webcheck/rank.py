import os
import urllib.parse
import requests
from urllib.parse import urlparse

def rank_handler(url):
    domain = urlparse(url).hostname if url else None
    if not domain:
        raise Exception('Invalid URL')

    try:
        auth = None
        if os.environ.get('TRANCO_API_KEY'):
            auth = (os.environ.get('TRANCO_USERNAME'), os.environ.get('TRANCO_API_KEY'))
        
        response = requests.get(
            f"https://tranco-list.eu/api/ranks/domain/{domain}",
            timeout=5.0,
            auth=auth
        )
        
        if not response.json() or not response.json().get('ranks') or len(response.json().get('ranks', [])) == 0:
            return {'skipped': f"Skipping, as {domain} isn't ranked in the top 100 million sites yet."}
        
        return response.json()
    except Exception as error:
        return {'error': f"Unable to fetch rank, {str(error)}"}

handler = rank_handler