import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

async def linkedPagesHandler(url):
    response = requests.get(url)
    html = response.text
    soup = BeautifulSoup(html, 'html.parser')
    internalLinksMap = {}
    externalLinksMap = {}
    
    # Get all links on the page
    for link in soup.find_all('a', href=True):
        href = link['href']
        absoluteUrl = urljoin(url, href)
        
        # Check if absolute / relative, append to appropriate map or increment occurrence count
        if absoluteUrl.startswith(url):
            count = internalLinksMap.get(absoluteUrl, 0)
            internalLinksMap[absoluteUrl] = count + 1
        elif href.startswith('http://') or href.startswith('https://'):
            count = externalLinksMap.get(absoluteUrl, 0)
            externalLinksMap[absoluteUrl] = count + 1
    
    # Sort by most occurrences, remove duplicates, and convert to array
    internalLinks = [entry[0] for entry in sorted(internalLinksMap.items(), key=lambda x: x[1], reverse=True)]
    externalLinks = [entry[0] for entry in sorted(externalLinksMap.items(), key=lambda x: x[1], reverse=True)]
    
    # If there were no links, then mark as skipped and show reasons
    if len(internalLinks) == 0 and len(externalLinks) == 0:
        return {
            'statusCode': 400,
            'body': {
                'skipped': 'No internal or external links found. '
                + 'This may be due to the website being dynamically rendered, using a client-side framework (like React), and without SSR enabled. '
                + 'That would mean that the static HTML returned from the HTTP request doesn\'t contain any meaningful content for Web-Check to analyze. '
                + 'You can rectify this by using a headless browser to render the page instead.'
            }
        }
    
    return {'internal': internalLinks, 'external': externalLinks}

handler = linkedPagesHandler