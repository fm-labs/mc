import requests
import zipfile
import csv
import os
from urllib.parse import urlparse
from io import StringIO

FILE_URL = 'https://s3-us-west-1.amazonaws.com/umbrella-static/top-1m.csv.zip'
TEMP_FILE_PATH = '/tmp/top-1m.csv'

def rank_handler(url):
    domain = None
    
    try:
        domain = urlparse(url).hostname
    except Exception as e:
        raise ValueError('Invalid URL')
    
    if not os.path.exists(TEMP_FILE_PATH):
        response = requests.get(FILE_URL, stream=True)
        response.raise_for_status()
        
        with zipfile.ZipFile(response.raw) as zip_ref:
            zip_ref.extractall('/tmp')
    
    with open(TEMP_FILE_PATH, 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile, fieldnames=['rank', 'domain'])
        
        for row in reader:
            if row['domain'] == domain:
                return {
                    'domain': domain,
                    'rank': row['rank'],
                    'isFound': True
                }
        
        return {
            'skipped': f'Skipping, as {domain} is not present in the Umbrella top 1M list.',
            'domain': domain,
            'isFound': False
        }

handler = rank_handler