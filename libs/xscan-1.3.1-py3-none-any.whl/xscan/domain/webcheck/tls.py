import requests
from urllib.parse import urlparse

MOZILLA_TLS_OBSERVATORY_API = 'https://tls-observatory.services.mozilla.com/api/v1'

async def tlsHandler(url):
    try:
        domain = urlparse(url).hostname
        scan_response = requests.post(f"{MOZILLA_TLS_OBSERVATORY_API}/scan?target={domain}")
        print("scan resonse", scan_response.text)
        scan_id = scan_response.json().get('scan_id')
        print("scan di", scan_id)

        if not isinstance(scan_id, int):
            return {
                'statusCode': 500,
                'body': {'error': 'Failed to get scan_id from TLS Observatory'},
            }
        
        result_response = requests.get(f"{MOZILLA_TLS_OBSERVATORY_API}/results?id={scan_id}")
        print("result response", result_response.text)
        return {
            'statusCode': 200,
            'body': result_response.json(),
        }
    except Exception as error:
        return {'error': str(error)}

handler = tlsHandler