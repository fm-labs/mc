import socket
import asyncio
from urllib.parse import urlparse
import concurrent.futures

DNS_SERVERS = [
    {'name': 'AdGuard', 'ip': '176.103.130.130'},
    {'name': 'AdGuard Family', 'ip': '176.103.130.132'},
    {'name': 'CleanBrowsing Adult', 'ip': '185.228.168.10'},
    {'name': 'CleanBrowsing Family', 'ip': '185.228.168.168'},
    {'name': 'CleanBrowsing Security', 'ip': '185.228.168.9'},
    {'name': 'CloudFlare', 'ip': '1.1.1.1'},
    {'name': 'CloudFlare Family', 'ip': '1.1.1.3'},
    {'name': 'Comodo Secure', 'ip': '8.26.56.26'},
    {'name': 'Google DNS', 'ip': '8.8.8.8'},
    {'name': 'Neustar Family', 'ip': '156.154.70.3'},
    {'name': 'Neustar Protection', 'ip': '156.154.70.2'},
    {'name': 'Norton Family', 'ip': '199.85.126.20'},
    {'name': 'OpenDNS', 'ip': '208.67.222.222'},
    {'name': 'OpenDNS Family', 'ip': '208.67.222.123'},
    {'name': 'Quad9', 'ip': '9.9.9.9'},
    {'name': 'Yandex Family', 'ip': '77.88.8.7'},
    {'name': 'Yandex Safe', 'ip': '77.88.8.88'}
]

KNOWN_BLOCK_IPS = [
    '146.112.61.106',
    '185.228.168.10',
    '8.26.56.26',
    '9.9.9.9',
    '208.69.38.170',
    '208.69.39.170',
    '208.67.222.222',
    '208.67.222.123',
    '199.85.126.10',
    '199.85.126.20',
    '156.154.70.22',
    '77.88.8.7',
    '77.88.8.8',
    '::1',
    '2a02:6b8::feed:0ff',
    '2a02:6b8::feed:bad',
    '2a02:6b8::feed:a11',
    '2620:119:35::35',
    '2620:119:53::53',
    '2606:4700:4700::1111',
    '2606:4700:4700::1001',
    '2001:4860:4860::8888',
    '2a0d:2a00:1::',
    '2a0d:2a00:2::'
]

def is_domain_blocked(domain, server_ip):
    try:
        addresses = socket.getaddrinfo(domain, None, socket.AF_INET)
        ipv4_addresses = [addr[4][0] for addr in addresses]
        if any(addr in KNOWN_BLOCK_IPS for addr in ipv4_addresses):
            return True
    except socket.gaierror:
        pass

    try:
        addresses = socket.getaddrinfo(domain, None, socket.AF_INET6)
        ipv6_addresses = [addr[4][0] for addr in addresses]
        if any(addr in KNOWN_BLOCK_IPS for addr in ipv6_addresses):
            return True
    except socket.gaierror as e:
        if e.errno == socket.EAI_NONAME or e.errno == socket.EAI_FAIL:
            return True
        return False

    return False

async def check_domain_against_dns_servers(domain):
    results = []
    
    with concurrent.futures.ThreadPoolExecutor() as executor:
        loop = asyncio.get_event_loop()
        tasks = []
        
        for server in DNS_SERVERS:
            task = loop.run_in_executor(
                executor, 
                is_domain_blocked, 
                domain, 
                server['ip']
            )
            tasks.append((server, task))
        
        for server, task in tasks:
            is_blocked = await task
            results.append({
                'server': server['name'],
                'serverIp': server['ip'],
                'isBlocked': is_blocked
            })
    
    return results

async def block_list_handler(url):
    parsed_url = urlparse(url)
    domain = parsed_url.hostname
    results = await check_domain_against_dns_servers(domain)
    return {'blocklists': results}

handler = block_list_handler