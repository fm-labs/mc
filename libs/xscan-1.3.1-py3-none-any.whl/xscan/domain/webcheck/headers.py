import requests
from typing import Dict, Any

def headers_handler(url: str, event: Dict[str, Any] = None, context: Any = None) -> Dict[str, str]:
    try:
        response = requests.get(url)
        response.raise_for_status()
        return dict(response.headers)
    except requests.RequestException as error:
        raise Exception(str(error))

handler = headers_handler