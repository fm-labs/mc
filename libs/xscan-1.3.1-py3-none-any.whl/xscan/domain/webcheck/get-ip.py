import socket
import asyncio

async def lookup_async(address):
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, socket.getaddrinfo, address, None)
        if result:
            ip = result[0][4][0]
            family = result[0][0]
            return {"ip": ip, "family": family}
        else:
            raise Exception("Address not found")
    except Exception as err:
        raise err

async def ip_handler(url):
    address = url.replace('https://', '').replace('http://', '')
    return await lookup_async(address)

handler = ip_handler