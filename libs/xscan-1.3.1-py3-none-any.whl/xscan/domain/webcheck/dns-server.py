import socket
import asyncio
import aiohttp
import re

async def dns_handler(url):
    try:
        domain = re.sub(r'^(?:https?://)?', '', url, flags=re.IGNORECASE)
        
        loop = asyncio.get_event_loop()
        addresses = await loop.run_in_executor(None, socket.gethostbyname_ex, domain)
        addresses = addresses[2]
        
        async def process_address(address):
            try:
                hostname_result = await loop.run_in_executor(None, socket.gethostbyaddr, address)
                hostname = hostname_result[0] if hostname_result else None
            except:
                hostname = None
            
            doh_direct_supports = False
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f'https://{address}/dns-query') as response:
                        doh_direct_supports = True
            except:
                doh_direct_supports = False
            
            return {
                'address': address,
                'hostname': hostname,
                'dohDirectSupports': doh_direct_supports
            }
        
        results = await asyncio.gather(*[process_address(addr) for addr in addresses])
        
        return {
            'domain': domain,
            'dns': results
        }
    except Exception as error:
        raise Exception(f"An error occurred while resolving DNS. {str(error)}")

handler = dns_handler