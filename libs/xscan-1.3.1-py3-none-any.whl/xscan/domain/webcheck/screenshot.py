import subprocess
import os
import tempfile
import base64
from pathlib import Path
import uuid
from urllib.parse import urlparse

def direct_chromium_screenshot(url):
    print(f"[DIRECT-SCREENSHOT] Starting direct screenshot process for URL: {url}")
    
    tmp_dir = tempfile.gettempdir()
    uuid_str = str(uuid.uuid4())
    screenshot_path = os.path.join(tmp_dir, f"screenshot-{uuid_str}.png")
    
    print(f"[DIRECT-SCREENSHOT] Will save screenshot to: {screenshot_path}")
    
    chrome_path = os.environ.get('CHROME_PATH', '/usr/bin/chromium')
    args = [
        chrome_path,
        '--headless',
        '--disable-gpu',
        '--no-sandbox',
        f'--screenshot={screenshot_path}',
        url
    ]
    
    print(f"[DIRECT-SCREENSHOT] Executing: {' '.join(args)}")
    
    try:
        result = subprocess.run(args, capture_output=True, text=True, check=True)
        
        with open(screenshot_path, 'rb') as f:
            screenshot_data = f.read()
        print("[DIRECT-SCREENSHOT] Screenshot read successfully")
        
        base64_data = base64.b64encode(screenshot_data).decode('utf-8')
        
        try:
            os.unlink(screenshot_path)
        except Exception as e:
            print(f"[DIRECT-SCREENSHOT] Failed to delete temp file: {e}")
        
        return base64_data
    except subprocess.CalledProcessError as e:
        print(f"[DIRECT-SCREENSHOT] Chromium error: {e}")
        raise e
    except Exception as e:
        print(f"[DIRECT-SCREENSHOT] Failed reading screenshot: {e}")
        raise e

def screenshot_handler(target_url):
    print(f"[SCREENSHOT] Request received for URL: {target_url}")
    
    if not target_url:
        print("[SCREENSHOT] URL is missing from queryStringParameters")
        raise ValueError("URL is missing from queryStringParameters")
    
    if not target_url.startswith('http://') and not target_url.startswith('https://'):
        target_url = 'http://' + target_url
    
    try:
        parsed_url = urlparse(target_url)
        if not parsed_url.scheme or not parsed_url.netloc:
            raise ValueError("Invalid URL format")
    except Exception as error:
        print(f"[SCREENSHOT] URL provided is invalid: {target_url}")
        raise ValueError("URL provided is invalid")
    
    try:
        print(f"[SCREENSHOT] Using direct Chromium method for URL: {target_url}")
        base64_screenshot = direct_chromium_screenshot(target_url)
        print("[SCREENSHOT] Direct screenshot successful")
        return {"image": base64_screenshot}
    except Exception as direct_error:
        print(f"[SCREENSHOT] Direct screenshot method failed: {direct_error}")
        print("[SCREENSHOT] Direct Chromium method failed, no fallback available")
        raise direct_error



handler = screenshot_handler