import os
import requests
from urllib.parse import quote

async def quality_handler(url, event=None, context=None):
    api_key = os.environ.get('GOOGLE_CLOUD_API_KEY')
    
    if not api_key:
        raise Exception(
            'Missing Google API. You need to set the `GOOGLE_CLOUD_API_KEY` environment variable'
        )
    
    endpoint = (
        f"https://www.googleapis.com/pagespeedonline/v5/runPagespeed?"
        f"url={quote(url)}&category=PERFORMANCE&category=ACCESSIBILITY"
        f"&category=BEST_PRACTICES&category=SEO&category=PWA&strategy=mobile"
        f"&key={api_key}"
    )
    
    response = requests.get(endpoint)
    return response.json()

handler = quality_handler