import requests
import base64
import xml.etree.ElementTree as ET
import json
import os
from urllib.parse import urlparse

async def get_google_safe_browsing_result(url):
    try:
        api_key = os.environ.get('GOOGLE_CLOUD_API_KEY')
        if not api_key:
            return {'error': 'GOOGLE_CLOUD_API_KEY is required for the Google Safe Browsing check'}
        
        api_endpoint = f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={api_key}"
        
        request_body = {
            'threatInfo': {
                'threatTypes': [
                    'MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE', 'POTENTIALLY_HARMFUL_APPLICATION', 'API_ABUSE'
                ],
                'platformTypes': ["ANY_PLATFORM"],
                'threatEntryTypes': ["URL"],
                'threatEntries': [{'url': url}]
            }
        }
        
        response = requests.post(api_endpoint, json=request_body)
        response_data = response.json()
        
        if response_data and 'matches' in response_data:
            return {
                'unsafe': True,
                'details': response_data['matches']
            }
        else:
            return {'unsafe': False}
    except Exception as error:
        return {'error': f'Request failed: {str(error)}'}

async def get_url_haus_result(url):
    try:
        domain = urlparse(url).hostname
        response = requests.post(
            'https://urlhaus-api.abuse.ch/v1/host/',
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data=f'host={domain}'
        )
        return response.json()
    except Exception as e:
        return {'error': f'Request to URLHaus failed, {str(e)}'}

async def get_phish_tank_result(url):
    try:
        encoded_url = base64.b64encode(url.encode()).decode()
        endpoint = f"https://checkurl.phishtank.com/checkurl/?url={encoded_url}"
        headers = {
            'User-Agent': 'phishtank/web-check',
        }
        response = requests.post(endpoint, headers=headers, timeout=3)
        
        root = ET.fromstring(response.text)
        results = {}
        for child in root.find('results'):
            results[child.tag] = child.text
        
        return results
    except Exception as error:
        return {'error': f'Request to PhishTank failed: {str(error)}'}

async def get_cloudmersive_result(url):
    api_key = os.environ.get('CLOUDMERSIVE_API_KEY')
    if not api_key:
        return {'error': 'CLOUDMERSIVE_API_KEY is required for the Cloudmersive check'}
    
    try:
        endpoint = 'https://api.cloudmersive.com/virus/scan/website'
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Apikey': api_key,
        }
        data = f'Url={requests.utils.quote(url)}'
        response = requests.post(endpoint, data=data, headers=headers)
        return response.json()
    except Exception as error:
        return {'error': f'Request to Cloudmersive failed: {str(error)}'}

async def threats_handler(url):
    try:
        url_haus = await get_url_haus_result(url)
        phish_tank = await get_phish_tank_result(url)
        cloudmersive = await get_cloudmersive_result(url)
        safe_browsing = await get_google_safe_browsing_result(url)
        
        if (url_haus.get('error') and phish_tank.get('error') and 
            cloudmersive.get('error') and safe_browsing.get('error')):
            raise Exception(f"All requests failed - {url_haus.get('error')} {phish_tank.get('error')} {cloudmersive.get('error')} {safe_browsing.get('error')}")
        
        return json.dumps({
            'urlHaus': url_haus,
            'phishTank': phish_tank,
            'cloudmersive': cloudmersive,
            'safeBrowsing': safe_browsing
        })
    except Exception as error:
        raise Exception(str(error))


handler = threats_handler