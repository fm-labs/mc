import json
import urllib.request
import urllib.parse
import ssl

async def dnssec_handler(domain):
    dns_types = ['DNSKEY', 'DS', 'RRSIG']
    records = {}
    
    for dns_type in dns_types:
        url = f"https://dns.google/resolve?name={urllib.parse.quote(domain)}&type={dns_type}"
        
        try:
            request = urllib.request.Request(url)
            request.add_header('Accept', 'application/dns-json')
            
            with urllib.request.urlopen(request) as response:
                data = response.read().decode('utf-8')
                dns_response = json.loads(data)
            
            if 'Answer' in dns_response and dns_response['Answer']:
                records[dns_type] = {
                    'isFound': True,
                    'answer': dns_response['Answer'],
                    'response': dns_response['Answer']
                }
            else:
                records[dns_type] = {
                    'isFound': False,
                    'answer': None,
                    'response': dns_response
                }
                
        except json.JSONDecodeError:
            raise Exception('Invalid JSON response')
        except Exception as error:
            raise Exception(f"Error fetching {dns_type} record: {str(error)}")
    
    return records

handler = dnssec_handler
