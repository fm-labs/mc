import requests
import json

def https_sec_handler(url):
    full_url = url if url.startswith('http') else f'http://{url}'
    
    try:
        response = requests.get(full_url)
        headers = response.headers
        return {
            'strictTransportPolicy': bool(headers.get('strict-transport-security')),
            'xFrameOptions': bool(headers.get('x-frame-options')),
            'xContentTypeOptions': bool(headers.get('x-content-type-options')),
            'xXSSProtection': bool(headers.get('x-xss-protection')),
            'contentSecurityPolicy': bool(headers.get('content-security-policy')),
        }
    except Exception as error:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(error)}),
        }

handler = https_sec_handler