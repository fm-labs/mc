from xscan.domain.scanners import DEFAULT_DOMAIN_SCANNERS
from xscan.runner import ScanRunner


class DomainScanRunner(ScanRunner):
    """
    ImageScanRunner is a class that manages the execution of image scans using the XScan library.
    It handles the initialization of the scanner, loading of image scanners, and execution of image scans.
    """

    def __init__(self, scanners: list=DEFAULT_DOMAIN_SCANNERS):
        """
        Initializes the ImageScanRunner instance.
        """
        super().__init__(scanners)
