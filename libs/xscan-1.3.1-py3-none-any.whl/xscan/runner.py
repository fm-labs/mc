import asyncio

from xscan.model import ScanConfig, ScanResult


class ScanRunner:
    """
    ScanRunner is a class that manages the execution of scans using the XScan library.
    It handles the initialization of the scanner, loading of scanners, and execution of scans.
    """

    def __init__(self, scanners: list=None):
        """
        Initializes the ScanRunner instance.
        """
        self.scanners = list()
        if scanners:
            self.scanners = scanners

    def before_scan(self, scan: ScanConfig):
        """
        Hook method to be called before the scan execution.
        Must return True to continue the scan, False to abort.
        Can be overridden in subclasses.
        """
        return True


    def after_scan(self, scan: ScanConfig, result: ScanResult):
        """
        Hook method to be called after the scan execution.
        Can be overridden in subclasses.
        """
        pass


    # def load_scanners(self, scanners: list):
    #     """
    #     Loads the scanners for the scanner.
    #     """
    #     for _scanner in scanners:
    #         if _scanner not in self.scanners:
    #             self.scanners.append(_scanner)


    def execute_scan(self, scan: ScanConfig):
        """
        Executes the scan using the loaded scanners.
        """
        print(f"Execute scan: {scan}")
        if not self.before_scan(scan):
            print(f"Scan {scan.target_id} aborted in before_scan hook.")
            return None

        result = ScanResult(scan)
        for scanner in self.scanners:
            try:
                if scanner.mode != scan.mode:
                    continue

                print(f"Init scanner {scanner.__name__} for target={scan.target}...")
                scanner_instance = scanner()

                #_result = scanner_instance.run(scan, result)

                # check if the run method is async
                if hasattr(scanner_instance.run, "__call__") and callable(scanner_instance.run):
                    if asyncio.iscoroutinefunction(scanner_instance.run):
                        print(f"RUNNER:Running async {scanner.__name__} for target={scan.target}...")
                        _result = asyncio.run(scanner_instance.run(scan, result))
                    else:
                        print(f"RUNNER:Running sync {scanner_instance.__name__} for target={scan.target}...")
                        _result = scanner_instance.run(scan, result)
                else:
                    print(f"Scanner {scanner.__name__} does not have a callable run method.")
                    continue

                print("Scanner result:", scanner.__name__, _result)
                if _result is not None:
                    result = _result
            except Exception as e:
                #result.code = 1
                #result.result = str(e)
                #return result
                print(f"Error running scanner {scanner.__name__} for target={scan.target}: {e}")
                continue


        print("Results:", result)

        artifacts = result.artifacts if result.artifacts else []
        for artifact_name in artifacts:
            #artifact = result.get_artifact(artifact_name)
            print(f"> Artifact: {artifact_name}")

        findings = result.findings if result.findings else []
        for finding in findings:
            print(f"! Finding: {finding}")

        # dump results
        #scan.dump_findings()
        #scan.dump_last_scan_timestamp()

        # cleanup
        #tmp_scan_dir = scan.tmp_dir
        #print(f"Cleaning up tmp scan directory: {tmp_scan_dir}")
        #if os.path.exists(tmp_scan_dir):
        #    shutil.rmtree(tmp_scan_dir, ignore_errors=True)

        self.after_scan(scan, result)
        print(f"Scan {scan.target_id} finished.")
        return result



    # def dump_last_scan_timestamp(self):
    #     last_scan_file = os.path.join(DATA_DIR, "scans", self.id, "last_scan")
    #     os.makedirs(os.path.dirname(last_scan_file), exist_ok=True)
    #     with open(last_scan_file, "w") as f:
    #         f.write(str(self.timestamp))
