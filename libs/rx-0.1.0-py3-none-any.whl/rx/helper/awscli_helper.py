import subprocess


def awscli_ecr_login(ecr_url, region="us-east-1", profile=None, access_key=None, secret_key=None) -> tuple[str, str, str]:
    """Login to AWS ECR using AWS CLI."""
    try:
        p_aws_env = {}
        p_aws_env["AWS_PROFILE"] = profile
        p_aws_env["AWS_ACCESS_KEY_ID"] = access_key
        p_aws_env["AWS_SECRET_ACCESS_KEY"] = secret_key

        p_aws = subprocess.run(
            ["aws", "ecr", "get-login-password", "--region", region],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            text=True,
            env=p_aws_env,
        )

        print("AWS ECR login successful!", p_aws.stdout, flush=True)
        ecr_password = p_aws.stdout.strip()
        ecr_username = "AWS"

        return ecr_url, ecr_username, ecr_password

    except subprocess.CalledProcessError as e:
        print("Docker login failed:", e.stderr, flush=True)
        raise e
