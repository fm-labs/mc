from rx.config import RunConfig, GlobalContext


def get_run_handler(run_cfg: RunConfig, ctx: GlobalContext):
    if not run_cfg.action:
        return None
    module_name = "rx.handler." + run_cfg.action.replace("-", "_")
    handler_name = "handler"
    try:
        module = __import__(module_name, fromlist=[handler_name])
        handler = getattr(module, handler_name)
    except (ImportError, AttributeError) as e:
        print(f"Error importing handler for {run_cfg.action}: {e}")
        handler = None
    return handler



def rx_run(run_cfg: RunConfig, ctx: GlobalContext) -> int:
    handler = get_run_handler(run_cfg, ctx)
    if not handler:
        raise ValueError(f"No handler found for run type: {run_cfg.action}")

    print(f"Using run handler: {handler.__module__}.{handler.__name__}")
    return handler(run_cfg, ctx)




# def get_run_handler(run_cfg: RunConfig, ctx: GlobalContext):
#     if not run_cfg.action:
#         return None
#     module_name = "rx.handler." + run_cfg.action
#     handler_name = "handler"
#     try:
#         module = __import__(module_name, fromlist=[handler_name])
#         handler = getattr(module, handler_name)
#     except (ImportError, AttributeError):
#         handler = None
#     return handler
# 
# def rx_run(run_cfg: RunConfig, ctx: GlobalContext) -> int:
#     handler = get_run_handler(run_cfg, ctx)
#     if not handler:
#         raise ValueError(f"No handler found for run_cfg type: {run_cfg.action}")
# 
#     print(f"Using run_cfg handler: {handler.__module__}.{handler.__name__}")
#     return handler(run_cfg, ctx)