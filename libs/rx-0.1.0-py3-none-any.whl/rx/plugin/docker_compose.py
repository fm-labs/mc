import subprocess
from pathlib import Path

from paramiko.client import SSHClient

from rx.config import RunConfig, GlobalContext
from rx.helper.sshpy_helper import ssh_connect, ssh_execute_command, ssh_params_from_url
from rx.helper.subprocess_helper import rx_subprocess
from rx.plugin.rsync import handle_rsync_run
from rx.util import split_url

def get_ssh_client(dest, ssh_cfg: dict) -> SSHClient:
    ssh_params = ssh_params_from_url(dest, ssh_params=ssh_cfg, use_ssh_config=True)
    print(f"SSH params: {ssh_params}")

    ssh_hostname = ssh_params.get("hostname")
    ssh_port = ssh_params.get("port")
    ssh_user = ssh_params.get("username")
    ssh_password = ssh_params.get("password")
    ssh_key_file = ssh_params.get("key_filename")
    ssh_key_pass = ssh_params.get("key_passphrase")
    try:
        client = ssh_connect(hostname=ssh_hostname, port=ssh_port,
                             username=ssh_user, password=ssh_password,
                             key_filename=ssh_key_file, key_passphrase=ssh_key_pass)
        if not client:
            raise ConnectionError(f"Failed to connect to {dest}")
        print(f"Connected to {dest}")
        return client
    except Exception as e:
        # print stack trace
        import traceback
        traceback.print_exc()

        print(f"SSH connection error: {e}")
        raise

def run_local_docker_compose_command(compose_dir: Path, compose_files: list, command: list):
    pass

def run_local_hook_script(local_compose_dir: Path, script_name: str) -> tuple[str, str, int]:
    setup_script = local_compose_dir / script_name
    if setup_script.exists() and setup_script.is_file():
        print(f"Found setup.sh script at {setup_script}, executing on remote host...")
        cmd_str = f"chmod +x setup.sh && ./setup.sh"
        try:
            stdout, stderr, rc = rx_subprocess(cmd_str, check=True, cwd=local_compose_dir, text=True, capture_output=True,)
        except subprocess.CalledProcessError as e:
            stdout = e.stdout
            stderr = e.stderr
            rc = e.returncode

        if rc != 0:
            raise RuntimeError(f"{script_name} failed with exit code {rc}")

        print(f"{script_name} exited with code {rc}")
        return stdout, stderr, rc


def run_remote_hook_script(client: SSHClient, remote_compose_dir: str, script_name: str) -> tuple[str, str, int]:
    try:
        cmd_str = f"cd {remote_compose_dir} && chmod +x {script_name} && bash ./{script_name}"
        print(f"Running command: {cmd_str}")
        stdout, stderr, rc = ssh_execute_command(client, cmd_str)
        print(f"{script_name} exited with code {rc}")
        return stdout, stderr, rc
    except Exception as e:
        print(f"SSH remote execution error: {e}")
        raise


def run_remote_docker_compose_command(client: SSHClient, remote_compose_dir: str, compose_files: list, command: list):
    pass


def upload_directory_via_rsync(local_dir: Path, dest: str, ssh_params: dict, ctx: GlobalContext):
    print(f"Syncing {local_dir} to {dest} ...")
    src = f"file://{local_dir}/"
    rsync_run_cfg = RunConfig(
        src=src,
        dest=str(dest),
        extra={"ssh": ssh_params},
    )
    handle_rsync_run(rsync_run_cfg, ctx)

def upload_directory_via_scp(local_dir: Path, remote_dir: str, ssh_params: dict):
    pass


def build_compose_command(project_dir: str, compose_cfg: dict, command: list) -> list:
    # construct docker compose command to be executed on remote host
    compose_files = []
    composefile_cfg = compose_cfg.get("composefile", "compose.yaml")
    if composefile_cfg:
        if isinstance(composefile_cfg, list):
            compose_files = composefile_cfg
        elif isinstance(composefile_cfg, str):
            compose_files = [composefile_cfg]

    # # auto-detect compose file if not specified
    # if len(compose_files) == 0:
    #     default_compose_files = [
    #         "compose",
    #         "compose.prod",
    #         "compose.override",
    #         "docker-compose",
    #         "docker-compose.prod",
    #         "docker-compose.override",
    #     ]
    #     for f in default_compose_files:
    #         for ext in [".yml", ".yaml"]:
    #             f_ext = f + ext
    #             if (ctx.cwd / shostpath / f_ext).exists():
    #                 compose_files.append(f_ext)

    if len(compose_files) == 0:
        raise FileNotFoundError("Compose file not specified.")

    cmd = ["docker", "compose",
           "--ansi", "never", "--progress", "plain",
           "--project-directory", project_dir,
           ]
    # add compose files
    for cf in compose_files:
        cmd += ["-f", f"{project_dir}/{cf}"]

    return cmd + command


def build_compose_up_command(project_dir: str, compose_cfg: dict) -> list:
    cmd = ["up", "-d", "--remove-orphans", "--build", "--force-recreate"]

    up_args = compose_cfg.get("up_args", [])
    if not isinstance(up_args, list):
        raise ValueError("compose.up_args must be a list")
    cmd += up_args
    return build_compose_command(project_dir, compose_cfg, cmd)



def handle_docker_compose_run(run_cfg: RunConfig, ctx: GlobalContext):
    src = run_cfg.src
    dest = run_cfg.dest
    ssh_cfg = run_cfg.extra.get("ssh", {})
    compose_cfg = run_cfg.extra.get("compose", {})

    # 1. validate required fields
    allowed_src_schemes = ["file", ]
    [sscheme, shostpath] = split_url(src)
    if sscheme not in allowed_src_schemes:
        raise ValueError(f"Unsupported source URL scheme: {sscheme}."
                         f" Supported schemes: {','.join(allowed_src_schemes)}")

    allowed_dest_schemes = ["ssh", "unix"]
    [dscheme, dhostpath] = split_url(dest)
    if dscheme not in allowed_dest_schemes:
        raise ValueError(f"Unsupported destination URL scheme: {dscheme}."
                         f" Supported schemes: {','.join(allowed_dest_schemes)}")


    local_compose_dir = (ctx.cwd / shostpath).resolve()
    remote_compose_dir = f"~/.rx/compose/{ctx.config.metadata.name}"

    # local deployment
    if dscheme == "unix":
        rsync_dest = Path(remote_compose_dir).resolve()
        rsync_dest.mkdir(parents=True, exist_ok=True)
        upload_directory_via_rsync(local_compose_dir, remote_compose_dir, ssh_cfg, ctx)

        # run setup.sh hook if exists
        if ctx.dry_run:
            print(f"Dry run mode, skipping setup.sh execution on {dest}")
        else:
            run_local_hook_script(rsync_dest, "setup.sh")

        docker_cmd = build_compose_up_command(str(rsync_dest), compose_cfg)
        try:
            stdout, stderr, rc = rx_subprocess(docker_cmd, ctx=ctx, check=True, cwd=local_compose_dir)
        except subprocess.CalledProcessError as e:
            stdout = e.stdout
            stderr = e.stderr
            rc = e.returncode
            print(f"Command exited with code {rc}", stderr)
            raise

    # remote deployment via SSH
    elif dscheme == "ssh":
        if ":" in dhostpath:
            raise ValueError(f"Destination URL must not contain a path. The path will be set to {remote_compose_dir}")

        rsync_dest = f"{dest}:{remote_compose_dir}"
        upload_directory_via_rsync(local_compose_dir, rsync_dest, ssh_cfg, ctx)

        # establish SSH connection
        client = get_ssh_client(dest, ssh_cfg)

        # run setup.sh if exists
        if ctx.dry_run:
            print(f"Dry run mode, skipping setup.sh execution on {dest}")
        else:
            run_remote_hook_script(client, remote_compose_dir, "setup.sh")

        docker_cmd = build_compose_up_command(remote_compose_dir, compose_cfg)
        try:
            cmd_str = " ".join(docker_cmd)
            print(f"Running command on remote {dest}: {cmd_str}")
            stdout, stderr, rc = ssh_execute_command(client, cmd_str)
        except Exception as e:
            print(f"SSH command error: {e}")
            raise
        print(f"Command exited with code {rc}")
