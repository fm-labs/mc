import os

# Docker
DOCKER_BIN=os.environ.get("DOCKER_BIN", default="docker")
DOCKER_SCOUT_BIN=os.environ.get("DOCKER_SCOUT_BIN", default="docker scout")
DOCKER_COMPOSE_BIN=os.environ.get("DOCKER_COMPOSE_BIN", default="docker compose")

# DockerHub
DOCKERHUB_USERNAME=os.environ.get("DOCKERHUB_USERNAME", default=None)
DOCKERHUB_PASSWORD=os.environ.get("DOCKERHUB_PASSWORD", default=None)

# Anchore Grype & Syft
SYFT_BIN=os.environ.get("SYFT_BIN", default="syft")
GRYPE_BIN=os.environ.get("GRYPE_BIN", default="grype")

# Dockle
DOCKLE_BIN=os.environ.get("DOCKLE_BIN", default="dockle")

# Trivy
TRIVY_BIN=os.environ.get("TRIVY_BIN", default="trivy")
