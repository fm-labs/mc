import abc

from xscan.model import ScanConfig, ScanResult


class BaseScanner(abc.ABC):
    """
    Class representing a scanner instance
    """

    name = "BaseScanner"
    mode = None
    description = "Base scanner class"

    def __repr__(self):
        return f"ScannerInstance(name={self.name}, mode={self.mode}, description={self.description})"

    def run(self, scan: ScanConfig, result: ScanResult) -> ScanResult:
        """
        Perform the scan.
        This method should be overridden by subclasses.
        """
        raise NotImplementedError("Subclasses must implement this method")
