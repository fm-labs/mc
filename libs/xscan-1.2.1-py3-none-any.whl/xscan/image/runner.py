from xscan import settings
from xscan.helper.docker_helper import docker_login
from xscan.image.scanners import DEFAULT_IMAGE_SCANNERS
from xscan.runner import ScanRunner
from xscan.model import ScanConfig, ScanResult


class ImageScanRunner(ScanRunner):
    """
    ImageScanRunner is a class that manages the execution of image scans using the XScan library.
    It handles the initialization of the scanner, loading of image scanners, and execution of image scans.
    """

    def __init__(self, scanners: list=DEFAULT_IMAGE_SCANNERS):
        """
        Initializes the ImageScanRunner instance.
        """
        super().__init__(scanners)


    def before_scan(self, scan: ScanConfig):
        """
        Prepares the scan runner before execution.
        """
        print(f"Preparing image scan: {scan}")
        if scan.mode != "image":
            print(f"Invalid scan mode for ImageScanRunner: {scan.mode}")
            return False

        #if not check_docker_scout():
        #    print("Docker Scout is not available. Please install and configure Docker Scout to proceed.")
        #    return False

        if settings.DOCKERHUB_USERNAME is not None and settings.DOCKERHUB_PASSWORD is not None:
            print("Logging in to Docker Hub...", settings.DOCKERHUB_USERNAME, settings.DOCKERHUB_PASSWORD)
            if not docker_login(settings.DOCKERHUB_USERNAME, settings.DOCKERHUB_PASSWORD):
                print("Docker login failed. Please check your credentials and try again.")
                return False

        return True

    def after_scan(self, scan: ScanConfig, result: ScanResult):
        """
        Cleans up after the scan execution.
        """
        print(f"Cleaning up after image scan: {scan}")

        # delete pulled image
        # if scan.mode == "image":
        #     try:
        #         print(f"Removing docker image: {scan.target}")
        #         remove_docker_image(scan.target)
        #     except Exception as e:
        #         print("Error removing docker image: {e}")
        #         raise e

        # cleanup
        #tmp_scan_dir = scan.tmp_dir
        #print(f"Cleaning up tmp scan directory: {tmp_scan_dir}")
        #if os.path.exists(tmp_scan_dir):
        #    shutil.rmtree(tmp_scan_dir, ignore_errors=True)
