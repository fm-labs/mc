import os

from xscan.helper.anchore_helper import run_syft, run_grype
from xscan.helper.docker_helper import docker_image_pull
from xscan.helper.docker_scout_helper import docker_scout_cves, docker_scout_recommendations
from xscan.helper.dockle_helper import run_dockle_image_scan
from xscan.helper.trivy_helper import run_trivy_image_scan
from xscan.base import BaseScanner


class DockerImagePuller(BaseScanner):

    name = "Docker Image Puller"
    mode = "image"
    description = "Pull docker images from registry"

    def run(self, scan, result):

        """
        Pull docker images from registry first
        """
        image_name = scan.target
        if not image_name:
            raise ValueError("Image name is required")

        try:
            # Pull docker image
            docker_image_pull(image_name)
        except Exception as e:
            print("Error pulling docker image: {e}")
            raise e


class DockerScoutCvesScanner(BaseScanner):
    """
    Scan docker images for vulnerabilities using docker scout
    """
    name = "docker_scout_cves"
    mode = "image"
    description = "Scan docker images for vulnerabilities using docker scout"

    def run(self, scan, result):
        """
        Scan docker images for vulnerabilities using docker scout
        """
        tmp_dir = scan.tmp_dir

        # cves_output_path = f"{tmp_dir}/cves_plain.txt"
        # docker_scout_cves(scan.target, output_format="packages", output=cves_output_path)
        # result.add_artifact_file("docker_scout/cves_plain.txt", cves_output_path)
        #
        # cves_spdx_output_path = f"{tmp_dir}/cves_spdx.json"
        # docker_scout_cves(scan.target, output_format="spdx", output=cves_spdx_output_path)
        # result.add_artifact_file("docker_scout/cves_spdx.json", cves_spdx_output_path)

        cves_sbom_output_path = f"{tmp_dir}/cves_sbom.json"
        docker_scout_cves(scan.target, output_format="sbom", output=cves_sbom_output_path)
        result.add_artifact_file("docker_scout/cves_sbom.json", cves_sbom_output_path)

        # @todo Process the spdx output
        # spdx_json_content = scan.get_artifact("docker_scout/cves_spdx.json")
        # if not spdx_json_content:
        #    raise ValueError("SPDX JSON file not found")

        # spdx_json = json.loads(spdx_json_content)
        # for vulnerability in spdx_json.get("vulnerabilities", []):
        #     result.add_finding(scanner=self.name,
        #                      type="vulnerability",
        #                      severity=vulnerability.get("severity"),
        #                      package=vulnerability.get("package"),
        #                      name=vulnerability.get("id"),
        #                      message=vulnerability.get("description"))
        return result


class DockerScoutRecommendationsScanner(BaseScanner):
    """
    Scan docker images for vulnerabilities using docker scout
    """
    name = "docker_scout_recommendations"
    mode = "image"
    description = "Scan docker images for vulnerabilities using docker scout"

    def run(self, scan, result):
        """
        Scan docker images for security recommendations using docker scout
        """
        tmp_dir = scan.tmp_dir

        recommendations_output_path = f"{tmp_dir}/recommendations_plain.txt"
        docker_scout_recommendations(scan.target, output=recommendations_output_path)
        result.add_artifact_file("docker_scout/recommendations_plain.txt",
                               recommendations_output_path)

        # result.add_finding(scanner=self.name,
        #                  severity="low",
        #                  name="package-nginx",
        #                  message="Recommendation found")
        return result


class AnchoreSyftScanner(BaseScanner):
    """
    Scan container images for SBOM using syft
    """
    name = "anchore_syft"
    mode = "image"
    description = "Scan docker images for vulnerabilities using syft"

    def run(self, scan, result):
        syft_output_format = "syft-json"
        syft_result = run_syft(scan.target, output_format=syft_output_format)
        result.add_artifact("syft/syft_sbom.json", syft_result)

        # syft_output_format = "syft-text"
        # syft_result = run_syft(scan.target, output_format=syft_output_format)
        # result.add_artifact("syft/syft_sbom.txt", syft_result)
        #
        # syft_output_format = "cyclonedx-json"
        # syft_result = run_syft(scan.target, output_format=syft_output_format)
        # result.add_artifact("syft/syft_sbom.cyclonedx.json", syft_result)
        #
        # syft_output_format = "spdx-json"
        # syft_result = run_syft(scan.target, output_format=syft_output_format)
        # result.add_artifact("syft/syft_sbom.spdx.json", syft_result)
        return result


class AnchoreGrypeScanner(BaseScanner):
    """
    Scan container images for vulnerabilities using grype
    """
    name = "anchore_grype"
    mode = "image"
    description = "Scan docker images for vulnerabilities using grype"

    def run(self, scan, result):
        source = scan.target

        # if we already have a syft sbom artifact from the syft scanner
        # use it as the source for grype
        sbom_path = result.get_artifact_file("syft/syft_sbom.json")
        if sbom_path is not None and os.path.exists(sbom_path):
            source = f"sbom:{sbom_path}"

        grype_output_format = "json"
        grype_result = run_grype(source, output_format=grype_output_format)
        result.add_artifact("grype/grype.json", grype_result)

        # Process the grype JSON output
        # todo move outside to helper
        # grype_json = json.loads(grype_result)
        # if grype_json.get("matches"):
        #     for match in grype_json["matches"]:
        #         vulnerability = match.get("vulnerability")
        #         if vulnerability:
        #             result.add_finding(scanner=self.name,
        #                              type="vulnerability",
        #                              severity=vulnerability.get("severity"),
        #                              package=match.get("artifact").get("name") + "@" + match.get("artifact").get("version"),
        #                              name=vulnerability.get("id"),
        #                              message=vulnerability.get("description"))

        # grype_output_format = "table"
        # grype_result = run_grype(source, output_format=grype_output_format)
        # result.add_artifact("grype/grype.table.txt", grype_result)
        #
        # grype_output_format = "cyclonedx-json"
        # grype_result = run_grype(source, output_format=grype_output_format)
        # result.add_artifact("grype/grype.cyclonedx.json", grype_result)
        #
        # grype_output_format = "sarif"
        # grype_result = run_grype(source, output_format=grype_output_format)
        # result.add_artifact("grype/grype.sarif.json", grype_result)
        return result



class TrivyContainerImageScanner(BaseScanner):
    """
    Scan container images for vulnerabilities using trivy
    """
    name = "trivy_container_image"
    mode = "image"
    description = "Scan docker images for vulnerabilities using trivy"

    def run(self, scan, result):
        #tmp_dir = scan.tmp_dir

        # Run Trivy scan
        trivy_result = run_trivy_image_scan(scan.target, output_format="json")
        result.add_artifact("trivy/image.json", trivy_result)
        
        #rivy_output_path = f"{tmp_dir}/image.cyclonedx.json"
        #run_trivy_image_scan(scan.target, output_format="cyclonedx", output=trivy_output_path)
        #result.add_artifact_file("trivy/image.cyclonedx.json", trivy_output_path)

        #trivy_output_path = f"{tmp_dir}/image.spdx.json"
        #run_trivy_image_scan(scan.target, output_format="spdx-json", output=trivy_output_path)
        #result.add_artifact_file("trivy/image.spdx.json", trivy_output_path)
        
        #trivy_output_path = f"{tmp_dir}/image.table.txt"
        #run_trivy_image_scan(scan.target, output_format="table", output=trivy_output_path)
        #result.add_artifact_file("trivy/image.table.txt", trivy_output_path)
        return result


class DockleContainerImageScanner(BaseScanner):
    """
    Scan container images for vulnerabilities using dockle
    """
    name = "dockle_container_image"
    mode = "image"
    description = "Scan docker images for vulnerabilities using dockle"

    def run(self, scan, result):
        #tmp_dir = scan.tmp_dir

        # Run Dockle scan
        dockle_result = run_dockle_image_scan(scan.target, output_format="json")
        result.add_artifact("dockle/image.json", dockle_result)

        # dockle_output_path = f"{tmp_dir}/image.sarif.json"
        # run_dockle_image_scan(scan.target, output_format="sarif", output_file=dockle_output_path)
        # result.add_artifact_file("dockle/image.sarif.json", dockle_output_path)
        return result


DEFAULT_IMAGE_SCANNERS = [
    DockerImagePuller,
    DockleContainerImageScanner,
    DockerScoutCvesScanner,
    DockerScoutRecommendationsScanner,
    AnchoreSyftScanner,
    AnchoreGrypeScanner,
    TrivyContainerImageScanner,
]
