import subprocess
from os import PathLike

from xscan import settings


def check_docker_scout() -> bool:
    """
    Check if Docker and Docker Scout are installed
    """
    try:
        # Check if Docker is installed
        subprocess.run([settings.DOCKER_BIN, "version"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Check if Docker Scout is installed
        cmd = settings.DOCKER_SCOUT_BIN.split(" ") + ["version"]
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        print("Docker and Docker Scout are installed.")
        return True
    except subprocess.CalledProcessError as e:
        #print(f"Error: {e.stderr.decode()}")
        #raise e
        print("Docker or Docker Scout is not installed. Please install them first.")
        return False


def docker_scout_cves(image_name: str, output_format: str = "packages", output: PathLike|str = None):
    """
    Scan docker images for vulnerabilities using docker scout cves

    :param image_name: Name of the docker image to scan
    :param output_format: Format of the output (default: "packages")
    :param output: Path to save the output (default: None)
    :return: str
    """
    try:
        print(f"Scanning {image_name} for {output_format} ...")
        # Run Docker Scout CVEs command
        cmd = settings.DOCKER_SCOUT_BIN.split(" ") + ["cves"]
        if output_format:
            cmd += ["--format", output_format]
        if output:
            cmd += ["--output", str(output)]
        cmd += [image_name]
        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Print the output
        #print(result.stdout.decode())
        return result.stdout.decode()
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr.decode()}")
        raise e


def docker_scout_recommendations(image_name: str, output: PathLike|str = None):
    """
    Get docker scout recommendations for image
    """
    try:
        cmd = settings.DOCKER_SCOUT_BIN.split(" ") + ["recommendations"]
        if output:
            cmd += ["--output", str(output)]
        cmd += [image_name]
        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Print the output
        #print(result.stdout.decode())
        return result.stdout.decode()
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr.decode()}")
        raise e
