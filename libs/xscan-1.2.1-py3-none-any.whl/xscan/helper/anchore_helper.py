import subprocess

def run_syft(image_name: str, output_format: str = "syft-json"):
    """
    Scan docker images for vulnerabilities using syft
    """
    try:
        print(f"Run syft for image={image_name} format={output_format} ...")
        cmd = ["syft", image_name]
        if output_format:
            cmd += ["-o", output_format]

        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Print the output
        # print(result.stdout.decode())
        return result.stdout.decode()
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr.decode()}")
        raise e


def run_grype(source: str, output_format: str = "json"):
    """
    Scan docker images for vulnerabilities using grype
    """
    try:
        print(f"Run grype for source={source} format={output_format} ...")
        cmd = ["grype", source]
        if output_format:
            cmd += ["-o", output_format]

        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Print the output
        # print(result.stdout.decode())
        return result.stdout.decode()
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr.decode()}")
        raise e

