import subprocess

from xscan import settings


def run_dockle_image_scan(image_name, output_format="json", output_file=None):
    """
    Scan docker images for vulnerabilities using dockle
    @see https://github.com/goodwithtech/dockle/

    :param image_name: The name of the docker image to scan
    :param output_format: The output format of the scan (json,sarif)
    :param output_file: The file to save the scan results
    """
    try:
        print(f"Init dockle image scan for image={image_name} ...")
        # Run Docker pull command
        dockle_opts = ["--exit-code", "0", "--exit-level", "fatal", "--quiet"]
        if output_format:
            dockle_opts += ["-f", output_format]
        if output_file:
            dockle_opts += ["-o", output_file]

        cmd = [settings.DOCKLE_BIN] + dockle_opts + [image_name]
        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        #print(result.stdout.decode())
        return result.stdout.decode()
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr.decode()}")
        raise e
