import requests

# Docker Hub API base
DOCKERHUB_API_BASE_URL = "https://hub.docker.com/v2"

def dockerhub_list_repos(username, pat):
    repos = []
    page = 1
    while True:
        url = f"{DOCKERHUB_API_BASE_URL}/repositories/{username}/?page={page}&page_size=100"
        response = requests.get(url, auth=(username, pat))

        if response.status_code != 200:
            raise Exception(f"Failed to fetch repos: {response.status_code}, {response.text}")

        data = response.json()
        repos.extend([repo["name"] for repo in data["results"]])

        if not data["next"]:  # no more pages
            break

        page += 1

    return repos


def dockerhub_login(username, password):
    url = f"{DOCKERHUB_API_BASE_URL}/users/login/"
    payload = {"username": username, "password": password}
    response = requests.post(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to login: {response.status_code}, {response.text}")

    data = response.json()
    print(f"Logged in as {data['username']}", data)
    return data["token"]
