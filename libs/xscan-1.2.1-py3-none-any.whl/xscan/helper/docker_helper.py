import subprocess

from xscan import settings

def docker_login(username: str, password: str):
    """
    Login to Docker with username and DockerHub PersonalAccessToken using subprocess
    """
    try:
        result = subprocess.run(
            ["docker", "login", "--username", username, "--password-stdin"],
            input=password,
            capture_output=True,
            text=True,
            check=True
        )
        print(result.stdout)
        print("✅ Successfully logged in to Docker Hub")
        return True
    except subprocess.CalledProcessError as e:
        print("❌ Docker login failed")
        print(e.stderr)
        raise e


def docker_image_pull(image_name):
    """
    Pull docker images from registry using subprocess
    """
    try:
        print(f"Pulling {image_name} ...")
        cmd = [settings.DOCKER_BIN, "pull", image_name]
        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        print(result.stdout.decode())
        print("✅ Successfully logged in to Docker Hub")
        return result.stdout.decode()
    except subprocess.CalledProcessError as e:
        print(e.stderr)
        print("❌ Docker image pull failed")
        raise e