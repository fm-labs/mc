from xscan.repo.scanners import DEFAULT_REPO_SCANNERS
from xscan.runner import ScanRunner
from xscan.model import ScanConfig, ScanResult


class RepoScanRunner(ScanRunner):
    """
    ImageScanRunner is a class that manages the execution of image scans using the XScan library.
    It handles the initialization of the scanner, loading of image scanners, and execution of image scans.
    """

    def __init__(self, scanners: list=DEFAULT_REPO_SCANNERS):
        """
        Initializes the ImageScanRunner instance.
        """
        super().__init__(scanners)


    def before_scan(self, scan: ScanConfig):
        """
        Prepares the scan before execution.
        """
        print(f"Preparing repo scan: {scan}")
        # todo clone/update repo
        return True


    def after_scan(self, scan: ScanConfig, result: ScanResult):
        """
        Cleans up after the scan execution.
        """
        print(f"Cleaning up after repo scan: {scan}")
        # todo delete cloned repo