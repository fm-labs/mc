import json

from xscan.helper.trivy_helper import run_trivy_repo_scan
from xscan.base import BaseScanner


class TrivyRepoScanner(BaseScanner):
    """
    Scan source code repositories for vulnerabilities using Trivy
    """
    name = "trivy_repo"
    mode = "repo"
    description = "Scan source code repositories for vulnerabilities using Trivy"

    def run(self, scan, result):
        env = scan.kwargs["environment"] if "environment" in scan.kwargs else {}

        trivy_result = run_trivy_repo_scan(scan.target, "vuln", output_format="json", env=env)
        result.add_artifact("trivy/repo_vuln.json", trivy_result)
        result.add_findings(self.parse_trivy_results_vulns(self.parse_trivy_results_str(trivy_result)))

        trivy_result = run_trivy_repo_scan(scan.target, "misconfig", output_format="json", env=env)
        result.add_artifact("trivy/repo_misconfig.json", trivy_result)
        result.add_findings(self.parse_trivy_results_misconfigs(self.parse_trivy_results_str(trivy_result)))

        trivy_result = run_trivy_repo_scan(scan.target, "license", output_format="json", env=env)
        result.add_artifact("trivy/repo_license.json", trivy_result)
        result.add_findings(self.parse_trivy_results_licenses(self.parse_trivy_results_str(trivy_result)))

        trivy_result = run_trivy_repo_scan(scan.target, "secret", output_format="json", env=env)
        result.add_artifact("trivy/repo_secrets.json", trivy_result)
        result.add_findings(self.parse_trivy_results_secrets(self.parse_trivy_results_str(trivy_result)))

        return result

    @staticmethod
    def parse_trivy_results_str(trivy_result_str: str):
        """
        Parse Trivy scan results from a JSON string.

        Args:
            trivy_result_str (str): JSON string of Trivy scan results.

        Returns:
            dict: Parsed Trivy scan results.
        """
        try:
            trivy_results = json.loads(trivy_result_str)
            return trivy_results
        except json.JSONDecodeError as e:
            print(f"Error parsing Trivy results: {e}")
            return {}

    @staticmethod
    def parse_trivy_results_vulns(trivy_results: dict):
        """
        Parse Trivy scan results to extract vulnerabilities.

        Args:
            trivy_results (list): List of Trivy scan results.

        Returns:
            list: List of parsed vulnerabilities.
        """
        if not trivy_results:
            return []

        findings = []
        #vulnerabilities = []
        for result in trivy_results.get('Results', []):
            if 'Vulnerabilities' in result and result['Vulnerabilities']:
                for vuln in result['Vulnerabilities']:
                    # vulnerability = {
                    #     'Target': result.get('Target', ''),
                    #     'Type': result.get('Type', ''),
                    #     'VulnerabilityID': vuln.get('VulnerabilityID', ''),
                    #     'PkgName': vuln.get('PkgName', ''),
                    #     'InstalledVersion': vuln.get('InstalledVersion', ''),
                    #     'FixedVersion': vuln.get('FixedVersion', ''),
                    #     'Severity': vuln.get('Severity', ''),
                    #     'Title': vuln.get('Title', ''),
                    #     'Description': vuln.get('Description', ''),
                    #     'References': vuln.get('References', []),
                    # }
                    # vulnerabilities.append(vulnerability)

                    finding = {
                        'title': vuln.get('Title', ''),
                        'description': f"VulnerabilityID: {vuln.get('VulnerabilityID', '')}\n"
                                       f"Package: {vuln.get('PkgName', '')}\n"
                                       f"InstalledVersion: {vuln.get('InstalledVersion', '')}\n"
                                       f"FixedVersion: {vuln.get('FixedVersion', '')}\n"
                                       f"Description: {vuln.get('Description', '')}\n"
                                       f"References: {', '.join(vuln.get('References', []))}",
                        'severity': vuln.get('Severity', 'unknown').upper(),
                        'type': 'vulnerability',
                        'tool': 'trivy',
                        'metadata': vuln,
                    }
                    findings.append(finding)
        return findings

    @staticmethod
    def parse_trivy_results_misconfigs(trivy_results: dict):
        """
        Parse Trivy scan results to extract misconfigurations.

        Args:
            trivy_results (list): List of Trivy scan results.

        Returns:
            list: List of parsed misconfigurations.
        """
        if not trivy_results:
            return []

        findings = []
        #misconfigurations = []
        for result in trivy_results.get('Results', []):
            if 'Misconfigurations' in result and result['Misconfigurations']:
                for misconf in result['Misconfigurations']:
                    # misconfiguration = {
                    #     'Target': result.get('Target', ''),
                    #     'Type': result.get('Type', ''),
                    #     'ID': misconf.get('ID', ''),
                    #     'Title': misconf.get('Title', ''),
                    #     'Description': misconf.get('Description', ''),
                    #     'Severity': misconf.get('Severity', ''),
                    #     'References': misconf.get('References', []),
                    # }
                    # misconfigurations.append(misconfiguration)

                    finding = {
                        'title': misconf.get('Title', ''),
                        'description': f"ID: {misconf.get('ID', '')}\n"
                                       f"Description: {misconf.get('Description', '')}\n",
                        'severity': misconf.get('Severity', 'unknown').upper(),
                        'type': 'misconfiguration',
                        'tool': 'trivy',
                        'metadata': misconf,
                    }
                    findings.append(finding)
        return findings

    @staticmethod
    def parse_trivy_results_licenses(trivy_results: dict):
        """
        Parse Trivy scan results to extract license issues.

        Args:
            trivy_results (list): List of Trivy scan results.

        Returns:
            list: List of parsed license issues.
        """
        if not trivy_results:
            return []

        findings = []
        #license_issues = []
        for result in trivy_results.get('Results', []):
            if 'Licenses' in result and result['Licenses']:
                for license in result['Licenses']:
                    # license_issue = {
                    #     'Target': result.get('Target', ''),
                    #     'Type': result.get('Type', ''),
                    #     'PkgName': license.get('PkgName', ''),
                    #     'InstalledVersion': license.get('InstalledVersion', ''),
                    #     'License': license.get('License', ''),
                    #     'Severity': license.get('Severity', ''),
                    #     'Title': license.get('Title', ''),
                    #     'Description': license.get('Description', ''),
                    #     'References': license.get('References', []),
                    # }
                    # license_issues.append(license_issue)
                    finding = {
                        'title': license.get('Title', ''),
                        'description': f"Package: {license.get('PkgName', '')}\n"
                                       f"InstalledVersion: {license.get('InstalledVersion', '')}\n"
                                       f"License: {license.get('License', '')}\n"
                                       f"Description: {license.get('Description', '')}\n",
                        'severity': license.get('Severity', 'unknown').upper(),
                        'type': 'license',
                        'tool': 'trivy',
                        'metadata': license,
                    }
                    findings.append(finding)
        return findings

    @staticmethod
    def parse_trivy_results_secrets(trivy_results: dict):
        """
        Parse Trivy scan results to extract secrets.

        Args:
            trivy_results (list): List of Trivy scan results.

        Returns:
            list: List of parsed secrets.
        """
        if not trivy_results:
            return []

        findings = []
        #secrets = []
        for result in trivy_results.get('Results', []):
            if 'Secrets' in result and result['Secrets']:
                for secret in result['Secrets']:
                    # secret_issue = {
                    #     'Target': result.get('Target', ''),
                    #     'Type': result.get('Type', ''),
                    #     'RuleID': secret.get('RuleID', ''),
                    #     'Category': secret.get('Category', ''),
                    #     'Severity': secret.get('Severity', ''),
                    #     'Title': secret.get('Title', ''),
                    #     'Description': secret.get('Description', ''),
                    #     'Match': secret.get('Match', ''),
                    #     'StartLine': secret.get('StartLine', 0),
                    #     'EndLine': secret.get('EndLine', 0),
                    #     'References': secret.get('References', []),
                    # }
                    # secrets.append(secret_issue)

                    finding = {
                        'title': secret.get('Title', ''),
                        'description': f"RuleID: {secret.get('RuleID', '')}\n"
                                       f"Category: {secret.get('Category', '')}\n"
                                       f"Description: {secret.get('Description', '')}\n"
                                       f"Match: {secret.get('Match', '')}\n"
                                       f"Location: Lines {secret.get('StartLine', 0)}-{secret.get('EndLine', 0)}\n",
                        'severity': secret.get('Severity', 'unknown').upper(),
                        'type': 'secret',
                        'tool': 'trivy',
                        'metadata': secret,
                    }
                    findings.append(finding)
        return findings



DEFAULT_REPO_SCANNERS = [
    TrivyRepoScanner,
]
