import os

from xscan.model import ScanResult, ScanConfig


def scanner(name: str, mode: str, description: str):
    """
    Decorator to register a scanner
    """
    print(f"Init Scanner: {name}")

    def decorator(func):

        def wrapper(*args, **kwargs):
            # Initialize the scan
            scan = init_scan(mode, args[0])
            # Add the scan object to kwargs
            kwargs["scan"] = scan
            # Call the original function
            try:
                result = func(*args, **kwargs)
                if not isinstance(result, ScanResult):
                    result = ScanResult(scan, 0, result)

            except Exception as e:
                # Handle exceptions and set result to error
                print(f"Error during scan: {e}")
                result = ScanResult(scan, 1, str(e))

            # Report the scan result
            dump_scan_result(scan, result)
            return result

        # Register the scanner
        #wrapper.name = name
        #wrapper.mode = mode
        #wrapper.description = description
        return wrapper

    return decorator




def dump_scan_result(scan: ScanConfig, result: ScanResult):
    """
    Report the scan result.
    Print the scan result to the scan directory.
    """
    print(f"Scan result reported: {result}")
    output_dir = scan.tmp_dir

    # Create a result file
    result_file = os.path.join(output_dir, "scan_result.txt")
    with open(result_file, "w") as f:
        f.write(f"Scan result for {scan.target}:\n")
        f.write(f"Code: {result.code}\n")
        f.write(f"Result: {result.result}\n")
    print(f"Scan result saved to {result_file}")



def init_scan(mode: str, target: str):
    """
    Initialize the scanner
    """
    scan = ScanConfig(mode, target)
    print(f"Scan initialized: {scan}")
    return scan

